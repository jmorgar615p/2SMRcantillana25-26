# data_model.py
# Backend del Hito 2 — Equipo 4

# Diccionario global de mascotas
mascotas = {}

def registrar_mascota():
    """
    Registra una mascota nueva.
    Incluye condicionales y manejo de excepciones.
    """
    try:
        nombre = input("Introduce el nombre de la mascota: ").strip()
        if nombre == "":
            print(" Error: el nombre no puede estar vacío.")
            return
        if nombre in mascotas:
            print(" Esta mascota ya existe. No se registrará.")
            return
        mascotas[nombre] = {"nivel": 1, "energia": 100}
        print(f" Mascota '{nombre}' registrada correctamente.")
    except Exception as e:
        print(" Error inesperado registrando mascota:", str(e))

def listar_mascotas():
    """
    Lista todas las mascotas registradas con manejo de excepciones.
    """
    try:
        if len(mascotas) == 0:
            print(" No hay mascotas registradas.")
            return
        print("\n Mascotas registradas:")
        for nombre, datos in mascotas.items():
            print(f"- {nombre}: Nivel {datos['nivel']}, Energía {datos['energia']}")
    except KeyError:
        print(" Error: clave inexistente al acceder a datos de mascotas.")
    except Exception as e:
        print(" Error inesperado al listar mascotas:", str(e))