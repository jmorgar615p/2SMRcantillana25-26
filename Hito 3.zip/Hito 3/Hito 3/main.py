from registro_entrenamientos import registrar_resultado_entrenamiento, log_evento

trainer = input("Elige tu entrenador:")
mascota = input("Elige tu mascota:")
resultado = "Victoria en 3 rondas"

log_evento("Inicio del entrenamiento")
log_evento("Ronda 1 completada")
log_evento("Ronda 2 completada")
log_evento("Ronda 3 completada")

registrar_resultado_entrenamiento(trainer, mascota, resultado)

log_evento("Entrenamiento finalizado")