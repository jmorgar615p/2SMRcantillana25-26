import json
import os

eventos = []

def log_evento(mensaje):
    print(mensaje)
    eventos.append(mensaje)

def registrar_resultado_entrenamiento(trainer, mascota, resultado):
    datos = {
        "trainer": trainer,
        "mascota": mascota,
        "resultado": resultado
    }

    archivo = "resultados_entrenamientos.json"

    try:
        if os.path.exists(archivo):
            with open(archivo, "r", encoding="utf-8") as f:
                registros = json.load(f)
        else:
            registros = []

        registros.append(datos)

        with open(archivo, "w", encoding="utf-8") as f:
            json.dump(registros, f, indent=4)

        log_evento("Resultado guardado correctamente.")

    except Exception as error:
        log_evento("Error al guardar el resultado:")
        log_evento(str(error))
